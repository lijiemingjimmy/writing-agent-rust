# WAM 报告 LaTeX 源码

## 在 TeXPage 打开

1. 新建项目，选择上传 ZIP，导入本压缩包。
2. 主文档选 `main.tex`，编译器选 **XeLaTeX**。
3. 点击编译。无需 Python、macOS、额外图片转换或 shell escape。

## 字体

- 中文正文、标题、表格和架构图：TeX Live 自带的 **Fandol 宋体**。普通字和粗体分别使用 FandolSong-Regular.otf、FandolSong-Bold.otf，按文件名加载，不查找 macOS 字体目录。
- 英文和数字：优先使用平台提供的 **Times New Roman**。
- 如果平台没有 Times New Roman，自动使用 TeX Live 自带的 **TeX Gyre Termes** 保证可以编译。它是 Times 风格的替代字体，不是 Times New Roman 本身；编译日志会提示这一替代。
- 如果必须严格使用 Times New Roman，请使用提供该字体的编译环境，或将你有权使用的字体文件上传到项目，再在 main.tex 中改为按相对文件路径加载。本包不打包商业系统字体。

中文字体来源：https://ctan.org/pkg/fandol

## 文件

- `main.tex`：编译入口、字体和版式设置。
- `sections/00-cover.tex`：标题、作者、摘要。
- `sections/01-content.tex`：报告正文，可直接修改。
- `figures/architecture.tex`：可编辑 TikZ 架构图，使用文档字体，不是截图。

`main.tex` 顶部包含 XeLaTeX 编译提示。本地可执行：

```sh
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

本包是设计报告源码，不是 Rust 应用源码。正文对应 2026-09-09 本地实现；应用开发成本 Excel 和完整原始 AI 对话不包含在本包中。
